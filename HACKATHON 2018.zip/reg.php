
<html>
<?php //$name = $_GET['n'];
//print  "$name";
?>
<?php echo "hey" ?>
</html>